Develop by Toan Pham Tran 
The programs in this file are used on a raspberry pi 3. 
You have to download the library WiringPi  to use all the program http://wiringpi.com/download-and-install/ 
