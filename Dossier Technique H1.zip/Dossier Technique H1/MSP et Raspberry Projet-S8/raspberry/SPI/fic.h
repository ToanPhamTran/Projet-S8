#ifndef FICHIER
#define FICHIER
void creation(void);
void initialisation(void);
void setLinuxClock (void);
void ajouter(unsigned short data, int ligne,int colonne);
void ajouter_clock(int ligne, int colonne);
void retour(int ligne, int colonne);
#endif
