#ifndef CONVERSION 
#define CONVERSION

int data_lum(unsigned short var1, unsigned short var2);
int data_so(unsigned short var1, unsigned short var2);
int data_vbr(unsigned short var1, unsigned short var2);
int data_co(unsigned short var1, unsigned short var2);

#endif
